<!DOCTYPE HTML>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<Link rel="stylesheet" href="css.css" />

<title>Webprosjekt 2010 gruppe 33</title>
</head>


<body>
<div id="boks">
<div id="header"><h1>Webprosjekt 2010 gruppe 33</h1></div>

<?php include "meny1.html"; ?>

<div id="midten">

<h3 class="overs">Individuelle rapporter</h3>

<ul class="sirkel">
    <li><a href="http://www.stud.hio.no/~s171639/rapport.html">Lars Helgeland</a></li>
    <li><a href="http://kennethlynne.net/emma/individuellrapport.html">Emma Gundersen Vea</a></li>
    <li><a href="http://www.stud.hio.no/~s168943/indrapport.html">Mats Taraldsen</a></li>
    <li><a href="http://www.stud.hio.no/~s169970/individuellrapport.html">Simen Christoffer Fredriksen</a></li>
</ul>


</div>



<div id="footer">
<p class="center">
      <a href="http://validator.w3.org/check/referer"><img
          src="img/html5val.jpg"
          alt="Valid HTML 5!" height="31" width="88" /></a>
</p>
<p class="center">
Sist oppdatert 01.11.2010.
</p>
</div>
</div>
</body>
</html>
