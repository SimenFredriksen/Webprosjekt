<!DOCTYPE HTML>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<Link rel="stylesheet" href="css.css" />

<title>Webprosjekt 2010 gruppe 33</title>
</head>


<body>
<div id="boks">
<div id="header"><h1>Webprosjekt 2010 gruppe 33</h1></div>

<?php include "meny1.html"; ?>

<div id="midten">
<h3 class="overs">Milep&aelig;lsplan</h3>
<div class="margfive">
<ul>
  <li>06.10.2010: Prosjektstart. </li>
  <li>06.10.2010: Valg av oppgave. </li>
  <li>06.10.2010: Problemstilling er valgt. </li>
  <li>06.10.2010: Ansvarsfordeling 1. leveranse. </li>
</ul>

<ul>
  <li>13.10.2010: Utkast styringsdokumenter. </li>
</ul>

<ul>
  <li>15.10.2010: Klargj&oslash;r dokumenter til 1. leveranse.</li>
</ul>

<ul>
  <li>18.10.2010: Levering av 1. leveranse.</li>
</ul>

<ul>
  <li>18.10.2010: Finne bedriftsnavn.</li>
</ul>

<ul>
  <li>20.10.2010: Ansvarsfordeling prosjektsiden.</li>
  <li>20.10.2010: Utkast prosjektside.</li>
</ul>

<ul>
  <li>27.10.2010: Ansvarsfordeling 2. leveranse.</li>
</ul>

<ul>
  <li>01.11.2010: Egenrapporter.</li>
  <li>01.11.2010: Samle stryringsdokumenter.</li>
</ul>

<ul>
  <li>03.11.2010: Klargj&oslash;r dokumenter til 2. leveranse.</li>
</ul>

<ul>
  <li>08.11.2010: Levering av 2. leveranse.</li>
</ul>

<ul>
  <li>10.11.2010: Oppdatere styringsdokumenter</li>
</ul>

<ul>
  <li>12.11.2010: Klargjøre framføringen</li>
</ul>
<ul>
  <li>15.11.2010: Framføring</li>
</ul>

<ul>
  <li>29.11.2010: Fullføre sluttrapporten</li>
</ul>

<ul>
  <li>30.11.2010: Finpusse siden</li>
  <li>30.11.2010: Sjekke for bugs og validering</li>
  <li>30.11.2010: Levering av 3. leveranse</li>
</ul>

</div>
</div>


<div id="footer">
<p class="center">
      <a href="http://validator.w3.org/check/referer"><img
          src="img/html5val.jpg"
          alt="Valid HTML 5!" height="31" width="88" /></a>
</p>
<p class="center">
Sist oppdatert 17.11.2010.
</p>
</div>
</div>
</body>
</html>
