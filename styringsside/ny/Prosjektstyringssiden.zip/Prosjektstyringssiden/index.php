<!DOCTYPE HTML>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<Link rel="stylesheet" href="css.css" />

<title>Webprosjekt 2010 gruppe 33</title>
</head>


<body>
<div id="boks">
<div id="header"><h1>Webprosjekt 2010 gruppe 33</h1></div>

<?php include "meny1.html"; ?>



<div id="midten">
<h3 class="overs">Prosjektstyringsside</h3>
<p>Gruppen best&aring;r av Emma Gundersen Vea, Lars Helgeland, Simen Christoffer Fredriksen
og Mats Taraldsen.
</p>
<p><strong>Leveranse 1</strong> finner man i menyen til venstre under "Styringsdokumenter".</p>
<p><strong>Leveranse 2</strong> finner man i menyen til venstre under "Styringsdokumenter", "Midtveisrapport" og "Sluttrapport".
V&aring;rt nettsted finnes under linken "Prosjektsiden" i menyen til venstre.</p>
<p><strong>Leveranse 3</strong> er nå klart. På denne siden finner man alt som har med styringen av prosjektet å gjøre.
V&aring;rt produkt finnes under linken "Prosjektsiden" i menyen til venstre.</p>
</div>



<div id="footer">
<p class="center">
      <a href="http://validator.w3.org/check/referer"><img
          src="img/html5val.jpg"
          alt="Valid HTML 5!" height="31" width="88" /></a>
</p>
<p class="center">
Sist oppdatert 14.12.2010.
</p>
</div>
</div>
</body>
</html>
