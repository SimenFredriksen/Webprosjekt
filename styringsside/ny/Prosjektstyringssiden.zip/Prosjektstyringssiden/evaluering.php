<!DOCTYPE HTML>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<Link rel="stylesheet" href="css.css" />

<title>Webprosjekt 2010 gruppe 33</title>
</head>


<body>
<div id="boks">
<div id="header"><h1>Webprosjekt 2010 gruppe 33</h1></div>

<?php include "meny1.html"; ?>



<div id="midten">
<h3 class="overs">Evaluering av prosjektet.</h3>
<ul>
  <li>Hvordan har samarbeidet i gruppa g&aring;tt?</li>
</ul>
<p>Samarbeidet har g&aring;tt veldig bra. Vi blir enige om det meste,
og alle gj&oslash;r de oppgavene de er utdelt.
<ul>
  <li>Hvordan har vi lykkes med &aring; f&oslash;lge fremdriftsplanen?</li>
</ul>
<p>Vi brukte lite tid p&aring; &aring; lage en plan for prosjektet v&aring;rt, og hoppet istedet rett i selve arbeidet.
Vi ser n&aring; at det kunne v&aelig;rt lurt &aring; bruke litt lengre tid p&aring; oppstartfasen neste gang vi har et prosjektarbeide.
Med det &aring; f&aring; bedre oversikt over hva som blir gjort, og hva som skal gj&oslash;res.
Men vi har p&aring; tross av d&aring;rlig planlegging hatt en bra, st&oslash;dig fremdrift i prosjektet.
<ul>
  <li>Har det dukket opp noe spesielt underveis i prosjektet som har p&aring;virket fremdriften,
  og hvordan har dere eventuelt h&aring;ndtert dette?</li>
</ul>
<p>Vi har hatt lite problemer, med unntak av at pc'en til Emma brøt sammen. Dette ble relativt fort fikset.</p>
</div>



<div id="footer">
<p class="center">
      <a href="http://validator.w3.org/check/referer"><img
          src="img/html5val.jpg"
          alt="Valid HTML 5!" height="31" width="88" /></a>
</p>
<p class="center">
Sist oppdatert 01.11.2010.
</p>
</div>
</div>
</body>
</html>
